package day17;

public class sdfg {
    public static void main(String[] args) {
        char c ='a';
        switch(c){

        }



    }
}
