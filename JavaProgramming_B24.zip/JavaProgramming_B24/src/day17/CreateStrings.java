package day17;

public class CreateStrings {
    public static void main(CreateStrings[] args) {

        String first = "java"; //String literal

        String second = new String("java");







    }
}
