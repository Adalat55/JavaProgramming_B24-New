package day07_unary_operators;

public class IncrementAndDecrement {
    public static void main(String[] args) {

        int n =0;
        n++;
        System.out.println(n); //1

        System.out.println(++n); //2
        System.out.println(n++);





    }


}
