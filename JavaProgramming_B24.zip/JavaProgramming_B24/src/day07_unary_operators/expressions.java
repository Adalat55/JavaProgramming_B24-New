package day07_unary_operators;

public class expressions {

    public static void main(String[] args) {
        double x = 2+3*2/5;


        System.out.println(x);






    }

}
