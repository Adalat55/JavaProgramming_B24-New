package day45_constructors;

public class UsingCar {
    public static void main(String[] args) {

        Car carOne = new Car(2021, "Ford","Focus","green", 600, 40_000, false);

        carOne.isOrdered();

        System.out.println(carOne);





    }
}
