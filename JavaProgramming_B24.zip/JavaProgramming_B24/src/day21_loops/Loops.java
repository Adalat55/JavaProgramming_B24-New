package day21_loops;

public class Loops {
    public static void main(String[] args) {

//        while(true){
//
        //System.out.println("hello world");

    int number =1;

    while(number<=100) {
        System.out.println("hello friend");
number++;
    }
        System.out.println(number);
    }


}

