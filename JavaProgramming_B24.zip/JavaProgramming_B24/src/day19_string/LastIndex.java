package day19_string;

public class LastIndex {
    public static void main(String[] args) {
        String str= "java";
        System.out.println(str.indexOf('v'));
        System.out.println(str.lastIndexOf('v'));

    }
}
