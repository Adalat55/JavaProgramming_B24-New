package day19_string;

public class Eachcharecter {
    public static void main(String[] args) {
         String java = "java";

         //charAt(number)

        System.out.println(java.charAt(0));
        System.out.println(java.charAt(1));
        System.out.println(java.charAt(2));
        System.out.println(java.charAt(3));
        System.out.println(java.charAt(100));


    }
}
