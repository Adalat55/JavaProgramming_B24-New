package day37_methods;
import my_utilities.StringUtil;
public class UsingStringUtilClass {
    public static void main(String[] args) {

        System.out.println(StringUtil.getDuplicateCharacters("javaa"));

    }
}
