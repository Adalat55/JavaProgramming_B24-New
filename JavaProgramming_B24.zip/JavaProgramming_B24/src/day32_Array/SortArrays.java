package day32_Array;

import java.util.Arrays;

public class SortArrays {
    public static void main(String[] args) {

        int[] nums = {4,1,60,-3,5,10};

        Arrays.sort(nums);
        System.out.println(Arrays.toString(nums));

    }
}
