package day32_Array;

import java.util.Arrays;

public class ArraysEquals {
    public static void main(String[] args) {

        char[] a = {1,2,3};
        char[] b = {49,50,51};


        System.out.println(Arrays.equals(a,b));



    }
}
