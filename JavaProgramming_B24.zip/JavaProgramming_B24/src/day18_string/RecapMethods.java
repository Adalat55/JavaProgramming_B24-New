package day18_string;

public class RecapMethods {
    public static void main(String[] args) {
        String day = "thursday";




    }
}
