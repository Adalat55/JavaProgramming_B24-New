package day18_string;

import java.util.Scanner;

public class ZoomPractice {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("kkjhkgjh");
        int num = input.nextInt();
        input.nextLine();
        System.out.println("klughkjhgk");
        String s = input.nextLine();
        System.out.println(s);
    }
}
