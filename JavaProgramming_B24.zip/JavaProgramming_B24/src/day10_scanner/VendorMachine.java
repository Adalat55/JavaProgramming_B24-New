package day10_scanner;

import java.util.Scanner;

public class VendorMachine {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

    }
}
