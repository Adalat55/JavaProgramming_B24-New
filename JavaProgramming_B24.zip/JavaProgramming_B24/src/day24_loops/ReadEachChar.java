package day24_loops;

public class ReadEachChar {
    public static void main(String[] args) {
        String s ="java";


        for(int i=0; i<s.length();i++)

        System.out.println(s.charAt(i));


    }
}
