package day24_loops;

public class Numbers {
    public static void main(String[] args) {

        int num=4;

        for(int i =1; i<=10; i++){
            System.out.println(num+"*"+i+"="+(num*i));
        }



    }
}
