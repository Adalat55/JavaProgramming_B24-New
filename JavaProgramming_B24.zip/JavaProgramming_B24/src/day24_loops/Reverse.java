package day24_loops;

public class Reverse {

    public static void main(String[] args) {

        for(int i = 20; i >= 0; i--){

            System.out.println(i);

        }

        System.out.println();

        for(int i = 20; i >= 0; i -= 2){

            System.out.println(i);

        }

//        int i = 0;
//        for( ; i < 4 ; ){
//
//        }



    }
}
