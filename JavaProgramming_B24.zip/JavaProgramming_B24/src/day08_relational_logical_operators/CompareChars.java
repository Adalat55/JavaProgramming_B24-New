package day08_relational_logical_operators;

public class CompareChars {

    public static void main(String[] args) {

        char z = 'z';
        char a = 'a';
        boolean zMoreThanA= z > a;

        System.out.println((int)z);

    }


}
