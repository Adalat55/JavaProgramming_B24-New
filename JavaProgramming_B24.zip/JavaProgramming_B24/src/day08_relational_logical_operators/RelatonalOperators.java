package day08_relational_logical_operators;

public class RelatonalOperators {

    public static void main(String[] args) {

        System.out.println("5>3: "+(5>3));

        System.out.println("");


    }
}
