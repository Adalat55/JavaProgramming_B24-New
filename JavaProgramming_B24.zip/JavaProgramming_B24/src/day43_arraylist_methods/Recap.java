package day43_arraylist_methods;

import java.util.ArrayList;

public class Recap {
    public static void main(String[] args) {

        ArrayList<String> first =new ArrayList<>();
        first.add("water");
        first.add("items");
        first.add("run");

        ArrayList<String> second=new ArrayList<>(first);

        ArrayList<String> third= new ArrayList<>(second);






    }
}
