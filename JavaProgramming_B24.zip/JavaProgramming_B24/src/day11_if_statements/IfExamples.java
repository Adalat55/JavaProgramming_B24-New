package day11_if_statements;

public class IfExamples {
    public static void main(String[] args) {
        if(true) {
            System.out.println("Hello world");
        }
        if(false){
            System.out.println("Hello world 2");
        }
    }

}
