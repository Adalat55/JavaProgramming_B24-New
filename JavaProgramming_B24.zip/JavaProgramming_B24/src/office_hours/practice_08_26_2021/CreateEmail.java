package office_hours.practice_08_26_2021;

public class CreateEmail {
    public static void main(String[] args) {
        /*
        Ask user to enter two strings. Both strings should be at least 6 character long. If they are shorter than that print “Invalid data” and program should end.
If the information provided is valid, you will take the first 4 characters of first string and combine them with the last three characters of the second string. At the end of your combined string add “@cybertek.com” and print the final string as your created email. The final email should be in all lowercase.
James Bond Jamie Bond

         */







    }
}
