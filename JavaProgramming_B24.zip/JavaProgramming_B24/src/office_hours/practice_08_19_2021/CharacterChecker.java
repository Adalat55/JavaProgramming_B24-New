package office_hours.practice_08_19_2021;

public class CharacterChecker {
    public static void main(String[] args) {

        char letter ='b';
        System.out.println((int)'a');
        if(letter>='a' &&letter<='z'){
            System.out.println("lowercase");
        }

    }
}
