package office_hours.practice_09_15_2021;

import java.util.Scanner;

public class ReverseEachWord {
    public static void main(String[] args) {

        Scanner input =new Scanner(System.in);
        System.out.println("enter your words separated by a space");
        String original = input.nextLine().trim();

        String [] words=original.split(" ");

    }
}
