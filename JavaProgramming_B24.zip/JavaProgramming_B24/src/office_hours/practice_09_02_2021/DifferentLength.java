package office_hours.practice_09_02_2021;

public class DifferentLength {
    public static void main(String[] args) {

        String s = "mouse";
        String s2="keyboard";

        String msg="mouseababkeyboardmouseabcdef";

        for(int i =0;i<msg.length(); i++){



        }

    }
}
