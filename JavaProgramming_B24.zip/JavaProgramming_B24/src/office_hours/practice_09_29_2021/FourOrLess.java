//package office_hours.practice_09_29_2021;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//
//public class FourOrLess {
//    public static ArrayList<String >getWordsLessThanFour(ArrayList<String> list){
//
//        ArrayList<String> list1 = new ArrayList<>(Arrays.asList( "apples", "tree", "loop", "cat", "animal", "shortcut"));
//       // System.out.println(getWordsLessThanFour(list1));
//return list;
//
//    }
//
//    public static ArrayList<String> getWordsLessThanFour(ArrayList<String> list){
//
//        ArrayList<String> validWords = new ArrayList<>();
//
//        for(String each : list){
//
//            if(each.length() <= 4){
//
//                validWords.add(each);
//
//            }
//list.removeIf(str -> str.equals("bond"));
//            return list;
//
//
//    }
//}
