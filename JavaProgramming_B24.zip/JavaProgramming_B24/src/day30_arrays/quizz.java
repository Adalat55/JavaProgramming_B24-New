package day30_arrays;

public class quizz {
    public static void main(String[] args) {
        int i=0;
        do{
            i++;//0,1,2,3,4
            System.out.println(i+ " ");
        }while(i<=4);
    }
}
