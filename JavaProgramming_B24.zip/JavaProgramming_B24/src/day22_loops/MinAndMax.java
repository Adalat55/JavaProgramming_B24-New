package day22_loops;

import java.util.Scanner;

public class MinAndMax {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int counter =1;

        while (counter<=5){

          counter++;
            System.out.println("Enter a number: ");
            int number= input.nextInt();



        }


    }
}
