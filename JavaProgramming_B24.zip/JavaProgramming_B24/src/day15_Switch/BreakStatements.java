package day15_Switch;

public class BreakStatements {
    public static void main(String[] args) {
        int i = 4;
        int b= 5;
        switch (i) {

            case 8:
                System.out.println("8");
                break;
            default:
                System.out.println("default");
                break;
            case 9:
                System.out.println("9");
                break;
            case 10:
                System.out.println("10");
                break;


        }



    }
}
