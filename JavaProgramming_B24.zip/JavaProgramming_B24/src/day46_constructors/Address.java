package day46_constructors;

public class Address {
    String street;
    String city;
    String state;
    String zipcode;
    String country;

    public Address(String street, String  city, String state, String zipcode, String country){

        street=street;
        city=city;
        state=state;
        zipcode=zipcode;
        country ="US";


    }
}
