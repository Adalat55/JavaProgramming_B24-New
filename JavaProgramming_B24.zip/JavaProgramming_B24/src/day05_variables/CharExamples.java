package day05_variables;

public class CharExamples {

    public static void main(String[] args) {

        char numb =9934;

        System.out.println(numb);



    }



}
