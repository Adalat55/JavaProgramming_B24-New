package day05_variables;

public class BooleanExamples {

    public static void main(String[] args) {

        boolean isSleepy = true;
        boolean isSunday = true;
        boolean isHungry = false;
        boolean isSunny = true;
         boolean isWeekend = true, isWeekday = false;
        System.out.println("isSleepy = " + isSleepy);
        System.out.println("isWeekday = " + isWeekday);
        System.out.println("isHungry = " + isHungry);
        System.out.println("isSunny = " + isSunny);
        System.out.println("isWeekend = " + isWeekend);
        System.out.println("isSunday = "+ isSunday);

    }






}
