package day05_variables;

public class MyName {

    public static void main(String[] args) {

        char letterOne = 65;
        char letterTwo = 68;
        char letterFour = 108;
        char letterSix = 84;

        System.out.println("my name: "+letterOne + letterTwo + letterOne + letterFour+ letterOne+ letterSix);
        System.out.print(letterOne);
        System.out.print(letterTwo);
        System.out.print(letterOne);
        System.out.print(letterFour);
        System.out.print(letterOne);
        System.out.print(letterSix);


        // concatenation
               // works with string
        //  combines the two parts together and the datatype of the value at end is a string




    }



}
