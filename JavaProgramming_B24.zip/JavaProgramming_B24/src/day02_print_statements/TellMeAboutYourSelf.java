package day02_print_statements;

public class TellMeAboutYourSelf {

    public static void main(String[] args) {

        System.out.println("Hello!");
        System.out.println("My name is Adalat");
        System.out.println("I live in California");
        System.out.println("I like to write Java");
        System.out.println("currently i am leraning java coding");
        System.out.println("5m");






    }


}
