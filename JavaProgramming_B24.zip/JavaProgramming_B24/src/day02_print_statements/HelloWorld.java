package day02_print_statements;

public class HelloWorld {

    public static void main(String[] args) {

       double a =10.5;
       int b= 15;
        double c= a*b;

        System.out.println(c);


        System.out.println("Hey");
    }

}



