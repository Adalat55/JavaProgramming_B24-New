package day40_arraylist;

public class ParsVsValueOf {
    public static void main(String[] args) {

        String s ="java";


    }
}
