package ExtraPractices;

public class SumOfNumbers {
    public static void main(String[] args) {

        int sumOfNumbers=0;

        for(int i=0; i<=100;i++){

            if(i%2==0){
                sumOfNumbers+=i;
            }


        }  System.out.print(sumOfNumbers);





    }
}
