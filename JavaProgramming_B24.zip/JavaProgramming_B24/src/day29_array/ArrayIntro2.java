package day29_array;

public class ArrayIntro2 {
    public static void main(String[] args) {


    }
}
