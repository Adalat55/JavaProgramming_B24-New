package day29_array;

import java.util.Scanner;

public class ScannerArray {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);





    }
}
