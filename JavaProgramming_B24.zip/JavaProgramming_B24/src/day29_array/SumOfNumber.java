package day29_array;

public class SumOfNumber {
    public static void main(String[] args) {

        int[] numbers = {4,1,4};

        int sum=0;



    }

}
