package day09_Scanner;

public class FruitExamples {
    public static void main(String[] args) {

        int apples = 5;
        boolean check = true;



    }
}
