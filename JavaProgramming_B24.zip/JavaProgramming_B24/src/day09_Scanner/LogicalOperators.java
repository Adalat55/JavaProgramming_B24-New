package day09_Scanner;

public class LogicalOperators {
    public static void main(String[] args) {
//        int a =3;
//        int z =40;
       int i = 5;
       boolean output = i>3 && i<40; //true & true

        int b=-4;
        b =-b--;

        System.out.println(b);




    }
}
