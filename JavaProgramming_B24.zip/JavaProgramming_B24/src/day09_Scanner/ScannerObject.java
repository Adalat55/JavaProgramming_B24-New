package day09_Scanner;

public class ScannerObject {

    public static void main(String[] args) {






    }
}
