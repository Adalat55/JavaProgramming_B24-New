package day09_Scanner;

import java.util.Scanner;

public class ScannerDate {
    public static void main(String[] args) {

      Scanner input = new Scanner(System.in);
        System.out.println("Enter the month number");


    }




}
