package day09_Scanner;
import java.util.Scanner;
public class Angles {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Enter your first name: ");
         String firstName = input.next();
        System.out.println("Enter your last name: ");
         String lastName = input.next();

        System.out.println("your full name: "+ firstName+ " "+ lastName);





    }}