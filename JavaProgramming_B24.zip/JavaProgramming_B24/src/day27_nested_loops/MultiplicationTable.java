package day27_nested_loops;

public class MultiplicationTable {
    public static void main(String[] args) {

        for(int i =0; i<=10;i++){

        }

    }
}
