package day27_nested_loops;

public class NestedLoopExample {
    public static void main(String[] args) {
        //print hello world 5 times
        //print hello universe 1 time
        //print hello world 5 times
        //print hello universe 1 time

        for(int i =0; i<5; i++){
            System.out.println("");
        }


    }
}
