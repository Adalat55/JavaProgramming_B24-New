package day04_variables;

public class Fruits {

    public static void main(String[] args) {

        int apples = 10;
        int grapes = 15;
        int bananas = 20;
        System.out.println("number of apples: " + apples);
        System.out.println("number of grapes: " + grapes);
        System.out.println("number of bananas: " + bananas);

        int totalNumberOfFruits = apples + grapes+ bananas;
        apples=50;
        int totalNumberOfFruitsafter = apples + grapes+ bananas;
        System.out.println("Total number of fruits: " + totalNumberOfFruitsafter);



        int month, day, year;// declare 3 int variables;



    }



}
