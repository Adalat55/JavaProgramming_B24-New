package day04_variables;

public class variables {

    public static void main(String[] args) {

      int month;
      int day;
      int year;

      month = 7;
      day = 31;
      year = 2021;

        System.out.println("Date: " + month+"/"+day+"/"+year);
        month= 8;
        day=1;
        System.out.println("Tomorrows date: " + month+"/"+day+"/"+year);








    }




}
