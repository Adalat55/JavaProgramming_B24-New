package day04_variables;

public class Store {

    public static void main(String[] args) {

        int totalNumberOfItems = 40;
        long totalWorth = 10_000_000_00L;
        double averagePriceOfItem = 330.31;
        float priceOfWatch1=100;


    }



}
