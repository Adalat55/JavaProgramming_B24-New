package day04_variables;

public class ExampleOne {

    public static void main(String[] args) {

        System.out.println("my name is Adalat");
        System.out.println("today is saturday");
        System.out.println("today is 31st");





    }


}
