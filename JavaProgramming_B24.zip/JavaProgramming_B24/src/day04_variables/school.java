package day04_variables;

public class school {
    public static void main(String[] args) {
        int totalNumberOfStudents;
        short numberOfStudentsIn1stGrade= 12;
        short numberOfStudentsIn2ndGrade= 15;
        short numberOfStudentsIn3rdGrade= 21;
        short numberOfStudentsIn4thGrade= 32;
        short numberOfStudentsIn5thGrade= 51;

        totalNumberOfStudents= numberOfStudentsIn1stGrade+numberOfStudentsIn2ndGrade+numberOfStudentsIn3rdGrade+numberOfStudentsIn5thGrade+numberOfStudentsIn4thGrade;


        System.out.println("in total there is  " + totalNumberOfStudents + " students");



    }



}
