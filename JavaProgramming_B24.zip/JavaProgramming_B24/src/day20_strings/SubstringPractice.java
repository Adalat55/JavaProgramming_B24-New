package day20_strings;

public class SubstringPractice {
    public static void main(String[] args) {

        String word = "abcdefghi";
                  //   012345678
        System.out.println(word.substring(4));
        System.out.println(word.substring(6));

        System.out.println(word.substring(4,5));





    }
}
