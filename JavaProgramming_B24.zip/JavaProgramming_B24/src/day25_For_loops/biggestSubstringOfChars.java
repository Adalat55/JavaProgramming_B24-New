package day25_For_loops;

public class biggestSubstringOfChars {
    public static void main(String[] args) {

        String s = "aaabbbcccccddddee";
         String longest="";
       for(int i=0;i<s.length();i++){


           }




       }



    }

