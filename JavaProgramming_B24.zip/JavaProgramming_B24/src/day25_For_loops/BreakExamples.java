package day25_For_loops;

public class BreakExamples {
    public static void main(String[] args) {






    }
}
