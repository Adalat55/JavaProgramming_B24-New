package day26_loops;

public class HTMLGenerator {
    public static void main(String[] args) {

        /*
        Given a String in the following format take the number part of the generator the html tagsEx:Input:div^2Output:<div></div><div></div>
         */





    }
}
