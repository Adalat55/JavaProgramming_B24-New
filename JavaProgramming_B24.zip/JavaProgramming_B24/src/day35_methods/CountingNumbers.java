package day35_methods;

public class CountingNumbers {

    public static void printing0to5(){
        for(int i =0; i<=5;i++){
            System.out.print(i+" ");
        }
    }

    public static void main(String[] args) {
        printing0to5();
    }
}
