package day34_methods;

public class UseCharacterMethods {
    public static void main(String[] args) {

            GetCharacters.printAtoZInUppercase();
            GetCharacters.printAtoZInLowercase();
            GetCharacters.PrintReverseZtoAUppercase();
            GetCharacters.PrintReverseZtoALowercase();
            GetCharacters.print0to9();

        }
    }

