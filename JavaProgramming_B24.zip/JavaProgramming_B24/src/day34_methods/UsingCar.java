package day34_methods;

public class UsingCar {
    public static void main(String[] args) {
        Car.driveInAHurry();

        System.out.println("hear police siren");

        Car.putOnBelts();
        Car.checkmirrors();
    }
}
