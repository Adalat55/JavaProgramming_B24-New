package day34_methods;

public class GreetingMethod {



    public static void greeting(String name){
        System.out.println("hello "+name+ ", how are you");
    }

    public static void main(String[] args) {
        greeting("Saim");
    }

}
