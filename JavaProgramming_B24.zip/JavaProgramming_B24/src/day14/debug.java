package day14;

public class debug {
    public static void main(String[] args) {
        int a =5;
        int b= 4;
        if(a>b){
            System.out.println();
        }
    }
}
