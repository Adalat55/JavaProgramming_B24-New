package replit_practices.untill_loops;

public class Sandwich {
    public static void main(String[] args) {


String word1="breadandbutter";
       String jam= word1.substring(word1.indexOf("b"),word1.indexOf("d")+1);
        System.out.println(jam);

    }
}
