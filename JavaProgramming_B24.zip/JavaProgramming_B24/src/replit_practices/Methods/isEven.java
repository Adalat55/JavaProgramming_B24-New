package replit_practices.Methods;

public class isEven {
    public static boolean isEven(int n) {

        boolean isEven=false;
        if(n%2==0){
            isEven=true;
        }
        return isEven;



    }
}
