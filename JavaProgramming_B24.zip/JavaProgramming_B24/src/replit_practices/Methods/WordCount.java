package replit_practices.Methods;

public class WordCount {
    public static int wordCount(String words) {
        // your code
        int wordCounter=words.split(" ").length;


     return wordCounter;
    }
}
