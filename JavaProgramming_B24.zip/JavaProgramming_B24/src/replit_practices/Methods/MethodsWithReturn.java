package replit_practices.Methods;

public class MethodsWithReturn {

public static boolean threeLocks(boolean a,boolean b, boolean c)  {

    boolean threeLocks=false;

    if(a==true&&b==true||c==true) {
        threeLocks = true;
    }
    return threeLocks;
}







}
