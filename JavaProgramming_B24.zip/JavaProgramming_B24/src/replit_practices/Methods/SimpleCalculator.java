package replit_practices.Methods;

import java.util.Scanner;

public class SimpleCalculator {
    public static void plus(){

        //your code here
        Scanner input =new Scanner(System.in);
        System.out.println("enter first number:");
        System.out.println("enter second number:");
        System.out.print("result:");
        System.out.println(input.nextInt()+ input.nextInt());




    }
}
