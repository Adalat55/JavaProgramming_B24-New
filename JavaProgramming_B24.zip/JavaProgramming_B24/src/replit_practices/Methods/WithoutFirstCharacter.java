package replit_practices.Methods;

public class WithoutFirstCharacter {
    public static String removeFirst(String target) {

        return target.substring(1);


    }
}
