package replit_practices.Methods;

public class Signum {
    public static void sign(int n){
        //your code here
        if(n>0){
            System.out.println("positive");
        }else if(n<0){
            System.out.println("negative");
        }else if(n==0){
            System.out.println("zero");
        }


    }
}
