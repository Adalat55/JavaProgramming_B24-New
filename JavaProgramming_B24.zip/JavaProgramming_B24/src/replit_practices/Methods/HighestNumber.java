package replit_practices.Methods;

public class HighestNumber {
    public static void main(String[] args) {
//
//        int [] nums= {9,5,3,67,45,67,150,-50};
//        int highest=nums[0];
//
//        for(int eachNumber: nums){
//            if(eachNumber>highest){
//                highest=eachNumber;
//            }
//        }
//        System.out.println(highest);
//
//

        System.out.println(main(5));
 }

    public static int main(int num){
        num*=num;
        return num;
    }
}
