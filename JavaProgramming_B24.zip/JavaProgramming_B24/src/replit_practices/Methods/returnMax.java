package replit_practices.Methods;

public class returnMax {
    public static int max(int x, int max){
        // Code here
            int maxNum=x;
            if(x>max){
                maxNum=x;
            }
            if(max>x){
                maxNum=max;
            }

        return maxNum;



    }
}
