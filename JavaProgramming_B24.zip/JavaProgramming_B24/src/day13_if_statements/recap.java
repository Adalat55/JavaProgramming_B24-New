package day13_if_statements;

public class recap {
    public static void main(String[] args) {
        int name =45;
        String Me= "name";
        if(Me.equals("name")) {
            System.out.println("i am good");
        }
    }
}
