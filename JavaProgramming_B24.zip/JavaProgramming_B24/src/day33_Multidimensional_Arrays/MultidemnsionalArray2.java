package day33_Multidimensional_Arrays;

public class MultidemnsionalArray2 {
    public static void main(String[] args) {

        int[][] arr = {

                {10, 20, 30, 40},
                {100, 200, 300, 400},
                {1000, 2000}
        };


    }
}
