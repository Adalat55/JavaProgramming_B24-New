package day31_arrays;

public class CharArrayToString {
    public static void main(String[] args) {

        char[] arr= {'f','r', 'i', 'd', 'a','y'};

        String str = new String(arr);


        System.out.println(str);
    }
}
