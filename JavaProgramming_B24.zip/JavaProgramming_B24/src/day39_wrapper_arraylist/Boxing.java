package day39_wrapper_arraylist;

public class Boxing {
    public static void main(String[] args) {

        int i =100;
        Integer i2=i;
        int b = i2;
        System.out.println(b);
    }
}
