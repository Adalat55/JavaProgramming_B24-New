package day39_wrapper_arraylist;

public class CharacterMethods {
    public static void main(String[] args) {
        System.out.println(Character.isUpperCase('a'));
        System.out.println(Character.isUpperCase('A'));
int a =45;
        System.out.println(Character.isDigit('a'));
    }
}
