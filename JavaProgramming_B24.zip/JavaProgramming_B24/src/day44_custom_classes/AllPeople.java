package day44_custom_classes;

public class AllPeople {
    public static void main(String[] args) {

        //make Person object

        Person personOne = new Person();

        personOne.name = "James Bond";
        personOne.age= 40;
        personOne.hariColor="black";
        personOne.sex = 'M';
        personOne.isMarried=false;




    }
}
