package day44_custom_classes;

public class App {

    String name;
    double version;
    boolean isFree;

    public void update(){
        System.out.println(name+ " is updating...");
        System.out.println(name+ " is updating...");
        System.out.println(name+ " is updating...");
    }



}
