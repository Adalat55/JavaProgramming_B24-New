package day44_custom_classes;

public class Person {

    //information /data
    /*
    name,age,hair color, sex, is married
     */

    //these are called instance variables

    String name;
    int age;
    String hariColor;
    char sex;
    boolean isMarried;

}
