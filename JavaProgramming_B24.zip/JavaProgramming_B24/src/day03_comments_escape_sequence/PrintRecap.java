package day03_comments_escape_sequence;

public class PrintRecap {

    public static void main(String[] args) {

        System.out.println("--------");
        System.out.println("|      |");
        System.out.println("|      |");
        System.out.println("--------");

        System.out.println(1);
        System.out.println(2.5);





    }




}
