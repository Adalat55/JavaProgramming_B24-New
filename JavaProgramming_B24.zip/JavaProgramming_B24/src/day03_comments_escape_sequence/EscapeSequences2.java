package day03_comments_escape_sequence;

public class EscapeSequences2 {
    public static void main(String[] args) {
        System.out.println("\t\t\"iphone case\", \"iphone\",");
        System.out.println("\"xbox\", \"webcam\", \"monitor\"");



    }


}
