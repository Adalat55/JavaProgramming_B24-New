package day03_comments_escape_sequence;

public class ShoppingReceipt {

    public static void main(String[] args) {


        System.out.println("******************************");
        System.out.println("\tWELCOME TO THE STORE");
        System.out.println("******************************");
        System.out.println("                               ");
        System.out.println("_______________________________");
        System.out.println("Cake                 $24");
        System.out.println("Water                $3.99");
        System.out.println("Apple Juice          $7.50");
        System.out.println("Bread                $4.25");
        System.out.println("                            ");
        System.out.println("_______________________________");
        System.out.println("TOTAL AMOUNT:        $39.74");
        System.out.println("TAX:                 $3.90");
        System.out.println("                             ");
        System.out.println("GRAND TOTAL:         $43.64");
        System.out.println("________________________________");
        System.out.println("********THANK YOU***************");
        System.out.println("                                  ");
        System.out.println("___________________________________");
        System.out.println("___________________________________");

    }


}
