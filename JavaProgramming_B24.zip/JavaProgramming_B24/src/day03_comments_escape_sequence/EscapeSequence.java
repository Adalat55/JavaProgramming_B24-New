package day03_comments_escape_sequence;

public class EscapeSequence {

    public static void main(String[] args) {

        System.out.println("I love 'java'\n\t programming");


        System.out.println("jhghgdgfc");

    }

}
