package day03_comments_escape_sequence;

public class EscapeSequences {
    public static void main(String[] args) {
        System.out.println("\t\tI like \"java\" programming");
        System.out.println("\t\tLets buy \"coffee\" and \"tea\"");




    }


}
