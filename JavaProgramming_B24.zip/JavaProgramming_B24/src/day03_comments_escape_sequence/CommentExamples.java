package day03_comments_escape_sequence;

public class CommentExamples {


    public static void main(String[] args) {

        System.out.println("Hello World");


        System.out.println("bye world");
//TODO





    }




}
