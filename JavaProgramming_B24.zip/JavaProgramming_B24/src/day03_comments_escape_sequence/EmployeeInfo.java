package day03_comments_escape_sequence;

public class EmployeeInfo {

    public static void main(String[] args) {


        System.out.println("Company name:\t\"Google\"");
        System.out.println("Employee:\t\t\"Khalid\"");
        System.out.println("ID:\t\t\t\t1234");
        System.out.println("Job Title:\t\tSDET");


    }
}
